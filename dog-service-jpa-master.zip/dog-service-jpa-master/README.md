# dog-service-jpa
This is a Spring Boot RESTful DogService for performing simple CRUD operations on Dog

## This repository is part of http://www.amitph.com tutorials.
> The dogs-service-jpa will be used as a Source Code example for **[Spring Data and JPA Tutorial](http://www.amitph.com/spring-data-and-jpa-tutorial/)** at http://www.amitph.com.

_The source code may be incomplete or written within a limited scope of the tutorial and some of the essential parts may have been ignored._